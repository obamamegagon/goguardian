(async () => {
  const status = document.getElementById('status');
  const error = document.getElementById('error');
  const retry = document.getElementById('retry');
  retry.onclick = () => location.reload();
  const fail = (message) => { error.textContent = message; error.hidden = false; retry.hidden = false; status.style.display = 'grid'; };
  try {
    if (location.hostname === 'cdn.jsdelivr.net') throw new Error('Open player.html on GitHub Pages, not jsDelivr. A CDN cannot run this service worker.');
    if (!window.isSecureContext || !navigator.serviceWorker) throw new Error('This player requires HTTPS (or localhost).');
    const base = new URL('./', location.href);
    const file = (name) => new URL(name, base).pathname;
    const cfg = window.POTATO_EMBED;
    const target = new URL(new URLSearchParams(location.search).get('go') || cfg.target);
    if (!['http:', 'https:'].includes(target.protocol)) throw new Error('Only HTTP and HTTPS pages are supported.');
    const relay = new URL(cfg.wisp);
    if (relay.protocol !== 'wss:' && !(location.hostname === 'localhost' && relay.protocol === 'ws:')) throw new Error('The relay must use secure WebSockets.');
    const { ScramjetController } = $scramjetLoadController();
    const controller = new ScramjetController({prefix:file('service/'),files:{wasm:file('assets/scramjet.wasm.wasm'),all:file('assets/scramjet.all.js'),sync:file('assets/scramjet.sync.js')}});
    await controller.init();
    const reg = await navigator.serviceWorker.register(file('sw.js'), {scope:file('./')});
    const worker = reg.installing || reg.waiting || reg.active;
    if (!worker) throw new Error('The proxy worker did not start.');
    if (worker.state !== 'activated') await new Promise((resolve,reject) => {
      const timeout = setTimeout(() => reject(new Error('Proxy worker startup timed out.')),15000);
      worker.addEventListener('statechange', () => { if (worker.state === 'activated') {clearTimeout(timeout);resolve();} else if(worker.state === 'redundant'){clearTimeout(timeout);reject(new Error('Proxy worker installation failed.'));} });
    });
    await new Promise((resolve,reject) => {
      const socket = new WebSocket(relay.href);
      const timer = setTimeout(() => {socket.close();reject(new Error('Your relay is not reachable. Check that the VPS is running.'));},10000);
      socket.onopen = () => {clearTimeout(timer);socket.close();resolve();};
      socket.onerror = () => {clearTimeout(timer);reject(new Error('Could not connect to your relay.'));};
    });
    const connection = new BareMux.BareMuxConnection(file('assets/baremux-worker.js'));
    await connection.setTransport(file('assets/epoxy.mjs'), [{wisp:relay.href}]);
    const frame = document.createElement('iframe');
    frame.title = 'PotatoLand browser';
    frame.setAttribute('sandbox','allow-scripts allow-same-origin allow-forms allow-popups allow-downloads');
    frame.allow = 'fullscreen; autoplay';
    frame.src = controller.encodeUrl(target.href);
    frame.onload = () => {status.style.display = 'none';};
    document.body.appendChild(frame);
  } catch (e) { fail(e.message || 'The player could not start.'); }
})();
