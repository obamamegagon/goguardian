importScripts('./assets/scramjet.all.js');
const { ScramjetServiceWorker } = $scramjetLoadWorker();
const scramjet = new ScramjetServiceWorker();
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', (event) => event.waitUntil(self.clients.claim()));
self.addEventListener('fetch', (event) => {
  event.respondWith((async () => {
    await scramjet.loadConfig();
    if (scramjet.route(event)) {
      try { return await scramjet.fetch(event); }
      catch { return new Response('The relay could not load this page. Retry or open PotatoLand directly.', {status:502, headers:{'Content-Type':'text/plain; charset=utf-8'}}); }
    }
    return fetch(event.request);
  })());
});
