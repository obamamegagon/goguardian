# PotatoLand SVG launcher

An SVG entry point plus a separately hosted Scramjet player. This is not a single-file offline proxy. The SVG loads `config.js` and `launcher.js`, then opens the HTTPS player. The supplied private Wisp endpoint must stay online.

## Important correction to the earlier advice

jsDelivr serves repository files; it is not a general website host. Service-worker registration on jsDelivr is not supported reliably, including its script MIME-type and origin requirements. Renaming HTML to SVG/XML does not remove these restrictions, guarantee execution, or make a site unblocked. SVG scripts do not run inside an `<img>` element. Browser/network policies and third-party storage restrictions still apply.

## Create the GitHub repository

1. Visit https://github.com/new and create a public repository named `potatoland-embed`.
2. In `config.js`, replace `https://YOURNAME.github.io/potatoland-embed/` with your actual GitHub Pages address. Keep the trailing slash.
3. Upload the CONTENTS of this folder using Add file → Upload files. `launch.svg`, `player.html`, and `assets/` must sit at the repository root, not inside an extra folder.
4. In the repository Settings → Pages, select Deploy from a branch, branch `main`, folder `/ (root)`, and Save.
5. Wait for GitHub Pages to finish publishing. Open `https://YOURNAME.github.io/potatoland-embed/player.html` first, then `/launch.svg`.
6. Create a release tagged `v1.0.0`. Your CDN SVG URL is:

   https://cdn.jsdelivr.net/gh/YOURNAME/potatoland-embed@v1.0.0/launch.svg

   CDN example script URL:

   https://cdn.jsdelivr.net/gh/YOURNAME/potatoland-embed@v1.0.0/launcher.js

7. Open the SVG as a document in its own tab, not as an image. It embeds your GitHub Pages player. If the CDN refuses active content or the browser blocks the embedded player, use the GitHub Pages `/launch.svg` or `/player.html` address instead. No claim is made that the CDN SVG executes in every browser.
8. For updates, publish a new tag such as `v1.0.1` and update the version in the CDN URL. Existing versioned URLs remain cached; cache purges are not guaranteed instant.

## Configuration

- `hostingBase`: the HTTPS folder containing `player.html` and `sw.js`.
- `wisp`: your Wisp relay; currently `wss://15.204.83.101.sslip.io/wisp/`.
- `mode`: `proxy` (through your relay) or `direct` (plain frame; set `target` to https://potatoland.dev/ for the real PotatoLand, which does not render through the proxy).
- `target`: initial site; currently `https://example.com/`.
- `player.html?go=https%3A%2F%2Fexample.com%2F` opens a different HTTP(S) page.

Use a separate repository/origin for this player, not a website holding sensitive accounts. Proxied pages execute scripts in the player's origin. Do not put passwords, API keys, or private relay credentials into a public repository. This package contains no account credentials. A public relay URL is visible to everyone and may need server-side usage limits.

The SVG and game frames do not permit navigation of the outermost page. Some websites require popups, storage, or other permissions and may not function. Framing PotatoLand itself through another proxy may conflict with its own worker; for the full site, opening https://potatoland.dev/ directly remains preferable.

## Included libraries

Scramjet, BareMux and Epoxy assets are copied unmodified from PotatoLand's public assets; their licenses are in `licenses/`. Scramjet and Epoxy come with AGPL-3.0 text, so if you publish modified versions you must offer the source. Keep these notices in a public repository. See THIRD_PARTY.md. The launcher code is MIT licensed.

## Checks

See VERIFICATION.md for the actual local test results. A new GitHub repository, Pages deployment, and jsDelivr URL cannot be verified until you create the repository; these instructions do not claim they are already published.
