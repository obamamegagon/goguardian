# Third-party code

- assets/scramjet.* : Scramjet 1.x, GNU AGPL-3.0 per the LICENSE file shipped in its npm package (its package.json says MIT; the two disagree, so check upstream), https://github.com/MercuryWorkshop/scramjet (licenses/Scramjet-LICENSE.txt)
- assets/baremux*.js : BareMux, license in licenses/BareMux.txt
- assets/epoxy.mjs : epoxy-transport, AGPL-3.0-only (licenses/EpoxyTransport-AGPL-3.0.txt). Corresponding source: https://github.com/MercuryWorkshop/epoxy-transport
  AGPL terms apply to this file; if you modify and offer it over a network, you must offer your modified source.
- These are copies of the files already served by PotatoLand, unmodified.
