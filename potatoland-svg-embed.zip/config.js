// Set hostingBase to your GitHub Pages address before uploading the repository.
// Example: https://YOURNAME.github.io/potatoland-embed/
window.POTATO_EMBED = Object.freeze({
  hostingBase: 'https://YOURNAME.github.io/potatoland-embed/',
  wisp: 'wss://15.204.83.101.sslip.io/wisp/',
  // 'proxy' sends target through your relay (works for ordinary sites).
  // 'direct' frames the target as-is, which is what PotatoLand itself needs.
  mode: 'proxy',
  target: 'https://example.com/',
  potatoland: 'https://potatoland.dev/'
});
