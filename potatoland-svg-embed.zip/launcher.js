(() => {
  const cfg = window.POTATO_EMBED;
  const status = document.getElementById('status');
  const open = document.getElementById('open');
  try {
    const base = new URL(cfg.hostingBase);
    if (base.hostname.includes('YOURNAME') || base.hostname.toLowerCase().includes('yourname')) throw new Error('Set hostingBase in config.js to your GitHub Pages address first.');
    const target = new URL(cfg.target);
    if (!['http:', 'https:'].includes(target.protocol)) throw new Error('Only web addresses are supported.');
    const direct = cfg.mode === 'direct';
    const url = direct ? target : new URL('player.html', base);
    if (!direct) url.searchParams.set('go', target.href);
    open.setAttribute('href', url.href);
    const frame = document.createElementNS('http://www.w3.org/1999/xhtml', 'iframe');
    frame.setAttribute('title', 'PotatoLand');
    frame.setAttribute('sandbox', 'allow-scripts allow-same-origin allow-forms allow-popups allow-downloads');
    frame.setAttribute('allow', 'fullscreen; autoplay');
    frame.setAttribute('style', 'position:fixed;inset:0;width:100%;height:100%;border:0;background:#fff');
    frame.setAttribute('src', url.href);
    document.getElementById('workspace').appendChild(frame);
    document.getElementById('loading').style.display = 'none';
  } catch (error) { status.textContent = error.message; }
})();
