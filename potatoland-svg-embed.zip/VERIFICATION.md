# Verification (local, headless Chromium)

- launch.svg opened as a document: the player iframe and proxied frame were created.
- player.html?go=https://example.com/ loaded through the relay and displayed correctly.
- https://potatoland.dev/ through the proxy showed PotatoLand's own error page (the React app fails to hydrate when rewritten). Use mode 'direct' for PotatoLand.
- Default start page is example.com, which renders correctly in launch.svg. https://duckduckgo.com/ hit React errors, and https://en.wikipedia.org/ loaded but unstyled (same 'destructured' problem seen in PotatoLand's own browser). Complex sites may not render properly.
- Not tested: real GitHub Pages deployment, the jsDelivr URL, or any school/network filter.
